// Stub para saveAppointment
export async function saveAppointment(appointment: any) {
  // Simula guardado
  return true;
}
