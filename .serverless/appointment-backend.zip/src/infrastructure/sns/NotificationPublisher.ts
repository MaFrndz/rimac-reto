// Stub para publishAppointment
export async function publishAppointment(appointment: any) {
  // Simula publicación
  return true;
}
